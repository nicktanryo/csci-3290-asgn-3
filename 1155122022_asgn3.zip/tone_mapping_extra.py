#
# CSCI3290 Computational Imaging and Vision *
# --- Declaration --- *
# I declare that the assignment here submitted is original except for source
# material explicitly acknowledged. I also acknowledge that I am aware of
# University policy and regulations on honesty in academic work, and of the
# disciplinary guidelines and procedures applicable to breaches of such policy
# and regulations, as contained in the website
# http://www.cuhk.edu.hk/policy/academichonesty/ *
# Assignment 3
# Name : Nicholas Tanryo
# Student ID : 1155122022
# Email Addr : nicholas.tanryo@link.cuhk.edu.hk
#

import threading
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import cv2
import numpy as np
from tone_mapping import bilateral_filter, compute_luminance, log_tonemap, durand_tonemap, map_luminance


class SelectOption:
    def __init__(self, parent, options, default_option, on_change):
        variable = tk.StringVar(parent)
        variable.set(default_option)
        variable.trace("w", lambda *args: on_change(variable, *args))

        widget = tk.OptionMenu(parent, variable, *options)

        self.variable = variable
        self.widget = widget
 


class Label:
    LOG = "Log"
    DURAND = "Durand"



class General(object):
    ENTRY_BORDER_COLOR = "#1555CC"

    TONE_MAPPING_METHOD = [
        Label.DURAND,
        Label.LOG
    ]


    ## default value
    LOG_ALPHA = 0.05

    DURAND_CONTRAST = 50
    DURAND_SIGMA_SPACE = lambda image: 0.02 * min(image.shape[0], image.shape[1])
    DURAND_SIGMA_RANGE = 0.04
    DURAND_SIZE = lambda sigma_space: int(2 * max(np.round(1.5 * sigma_space), 1) + 1)


    @staticmethod
    def hdr_read(filename: str) -> np.ndarray:
        img = cv2.imread(filename, cv2.IMREAD_ANYDEPTH)
        return img


    @staticmethod
    def hdr_read_for_thumbnail(filename: str):
        img = cv2.imread(filename)
        img = General.bgr_to_rgb(img)
        return img


    @staticmethod
    def ldr_write(filename: str, image: np.ndarray) -> None:
        return cv2.imwrite(filename, image)


    @staticmethod
    def bgr_to_rgb(image: np.ndarray):
        return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)


    @staticmethod
    def format_label(label: str):
        return "{:8s}".format(label)

    
    @staticmethod
    def str_to_num_validator(str_value: str):
        number = "".join([ c for c in str_value if c.isnumeric() or c == "."])
        if number == "":
            return "0"
        else:
            return number
        


class ParameterFrame(tk.Frame):
    def __init__(self, parent: tk.Frame, app: "MyApp"):
        tk.Frame.__init__(self, parent)
        self.app = app

        self.main_frame = tk.Frame(parent)
        self.display_parameters(self.main_frame)
        
        # from tkinter import ttk
        # self.contrast_slider = ttk.Scale(self.main_frame, from_=0, to=100, orient=tk.HORIZONTAL, command=self.on_contrast_change)
        # self.contrast_slider.set(self.contrast_variable.get())
        # # contrast_label.pack()
        # self.contrast_slider.grid(row=2, column=0, columnspan=4, sticky=tk.EW)


    def display_parameters(self, parent_frame: tk.Frame):

        for widget in parent_frame.winfo_children():
            widget.grid_forget()

        if not (hasattr(self, "tone_map_method_label") and hasattr(self, "select_option")):
            self.tone_map_method_label = tk.Label(parent_frame, text="{}:".format(General.format_label("Method")))

            self.select_option = SelectOption(parent_frame, [v for v in General.TONE_MAPPING_METHOD], self.app.method, self.on_method_change)
            self.select_option.widget.config(width=16)

        self.tone_map_method_label.grid(row=0, column=0, columnspan=2)
        self.select_option.widget.grid(row=0, column=2, columnspan=2, sticky=tk.W)

        if self.app.method == Label.DURAND:
            ## render durand parameter
            self.create_durand_method_widget(parent_frame)
            self.render_durand_method_widget()
        else:
            ## render log parameter
            self.create_log_method_widgets(parent_frame)
            self.render_log_method_widgets()

        for widget in parent_frame.winfo_children():
            if isinstance(widget, tk.Entry):
                widget.focus()


    def change_attribute(self, method: str, attribute: str, value):
        self.app.on_tonemap_attribute_change(method, attribute, value)


    def create_log_method_widgets(self, parent: tk.Frame):
        if hasattr(self, "alpha_variable") and hasattr(self, "alpha_label") and hasattr(self, "contrast_input"):
            return 

        self.alpha_variable = tk.StringVar()
        self.alpha_variable.set(self.app.TONE_MAP[Label.LOG]["alpha"])
        self.alpha_variable.trace("w", lambda *args: self.change_attribute(Label.LOG, "alpha", float(General.str_to_num_validator(self.alpha_variable.get()))))

        self.alpha_label = tk.Label(parent, text="{}:".format(General.format_label("Alpha")), pady=10)
        self.alpha_input = tk.Entry(
            parent, textvariable=self.alpha_variable,
            highlightthickness=3, highlightbackground=General.ENTRY_BORDER_COLOR, highlightcolor=General.ENTRY_BORDER_COLOR)
    

    def render_log_method_widgets(self):
        self.alpha_label.grid(row=1, column=0, columnspan=2, sticky=tk.W)
        self.alpha_input.grid(row=1, column=2, columnspan=2)


    def create_durand_method_widget(self, parent: tk.Frame):
        if hasattr(self, "contrast_label") and hasattr(self, "contrast_input"):
            return

        self.contrast_variable = tk.StringVar()
        self.contrast_variable.set(self.app.TONE_MAP[Label.DURAND]["contrast"])
        self.contrast_variable.trace("w", lambda *args: self.change_attribute(Label.DURAND, "contrast", int(General.str_to_num_validator(self.contrast_variable.get()))))

        self.contrast_label = tk.Label(parent, text="{}:".format(General.format_label("Contrast")), pady=10)
        self.contrast_input = tk.Entry(
            parent, textvariable=self.contrast_variable,
            highlightthickness=3, highlightbackground=General.ENTRY_BORDER_COLOR, highlightcolor=General.ENTRY_BORDER_COLOR)


        self.sigma_space_variable = tk.StringVar()
        self.sigma_space_variable.set(self.app.TONE_MAP[Label.DURAND]["sigma_space"])
        self.sigma_space_variable.trace("w", lambda *args: self.change_attribute(Label.DURAND, "sigma_space", float(General.str_to_num_validator(self.sigma_space_variable.get()))))

        self.sigma_space_label = tk.Label(parent, text="{}:".format(General.format_label("σ-space")), pady=10)
        self.sigma_space_input = tk.Entry(
            parent, textvariable=self.sigma_space_variable,
            highlightthickness=3, highlightbackground=General.ENTRY_BORDER_COLOR, highlightcolor=General.ENTRY_BORDER_COLOR)


        self.sigma_range_variable = tk.StringVar()
        self.sigma_range_variable.set(self.app.TONE_MAP[Label.DURAND]["sigma_range"])
        self.sigma_range_variable.trace("w", lambda *args: self.change_attribute(Label.DURAND, "sigma_range", float(General.str_to_num_validator(self.sigma_range_variable.get()))))

        self.sigma_range_label = tk.Label(parent, text="{}:".format(General.format_label("σ-range")), pady=10)
        self.sigma_range_input = tk.Entry(
            parent, textvariable=self.sigma_range_variable,
            highlightthickness=3, highlightbackground=General.ENTRY_BORDER_COLOR, highlightcolor=General.ENTRY_BORDER_COLOR)


        self.size_variable = tk.StringVar()
        self.size_variable.set(self.app.TONE_MAP[Label.DURAND]["size"])
        self.size_variable.trace("w", lambda *args: self.change_attribute(Label.DURAND, "size", int(General.str_to_num_validator(self.size_variable.get()))))

        self.size_label = tk.Label(parent, text="{}:".format(General.format_label("Size")), pady=10)
        self.size_input = tk.Entry(
            parent, textvariable=self.size_variable,
            highlightthickness=3, highlightbackground=General.ENTRY_BORDER_COLOR, highlightcolor=General.ENTRY_BORDER_COLOR)


    def render_durand_method_widget(self):
        self.contrast_label.grid(row=1, column=0, columnspan=2, sticky=tk.W)
        self.contrast_input.grid(row=1, column=2, columnspan=2)
        self.sigma_space_label.grid(row=2, column=0, columnspan=2, sticky=tk.W)
        self.sigma_space_input.grid(row=2, column=2, columnspan=2)
        self.sigma_range_label.grid(row=3, column=0, columnspan=2, sticky=tk.W)
        self.sigma_range_input.grid(row=3, column=2, columnspan=2)
        self.size_label.grid(row=4, column=0, columnspan=2, sticky=tk.W)
        self.size_input.grid(row=4, column=2, columnspan=2)


    def on_method_change(self, variable: tk.StringVar, *args):
        self.app.method = variable.get()
        self.display_parameters(self.main_frame)


    def on_update_default_value(self):
        if hasattr(self, "alpha_variable"):
            self.alpha_variable.set(self.app.TONE_MAP[Label.LOG]["alpha"])

        if hasattr(self, "contrast_variable"):
            self.contrast_variable.set(self.app.TONE_MAP[Label.DURAND]["contrast"])

        if hasattr(self, "sigma_space_variable"):
            self.sigma_space_variable.set(self.app.TONE_MAP[Label.DURAND]["sigma_space"])

        if hasattr(self, "sigma_range_variable"):
            self.sigma_range_variable.set(self.app.TONE_MAP[Label.DURAND]["sigma_range"])

        if hasattr(self, "size_variable"):
            self.size_variable.set(self.app.TONE_MAP[Label.DURAND]["size"])



class ActionButtonsFrame(tk.Frame):
    def __init__(self, parent, app: "MyApp"):
        tk.Frame.__init__(self, parent)
        self.app = app

        self.main_frame = tk.Frame(parent)

        upload_button = tk.Button(self.main_frame, text="Upload Image", command=self.upload_file)
        upload_button.pack(fill="x", expand="True")

        self.upload_status_label = tk.Label(self.main_frame, text=" ", pady=5)
        self.upload_status_label.pack(fill="x", expand="True")

        self.run_button = tk.Button(self.main_frame, text="Run", command=self.on_run_tonemapping)
        self.run_button["state"] = tk.DISABLED if self.app.image == None else tk.NORMAL
        self.run_button.pack(fill="x", expand="True")

        self.progress_bar = ttk.Progressbar(self.main_frame, mode="determinate", value=0, maximum=100)
        self.progress_bar.pack(fill="x", expand="True")

        self.download_button = tk.Button(self.main_frame, text="Download Result", command=self.download_image)
        self.download_button.pack(fill="x", expand="True")
        self.download_button["state"] = tk.DISABLED if self.app.result_8bit == None else tk.NORMAL


    def upload_file(self, event=None):
        from tkinter import filedialog
        filename = filedialog.askopenfilename(filetypes=[("HDR files", "*.hdr")])

        if filename != "":
            self.app.on_file_upload(filename)
            self.upload_status_label.config(text="File: {}".format(filename.split("/")[-1]), foreground='green', anchor=tk.W)
            self.run_button["state"] = tk.NORMAL


    def download_image(self, event=None):
        self.app.on_download_result()

    
    def on_run_tonemapping(self, event=None):
        self.progress_bar_thread = threading.Thread(target=self.handle_progress_bar, args=(event,))
        self.progress_bar_thread.start()
        
    
    def handle_progress_bar(self, event=None):
        self.progress_bar.config(mode='indeterminate', value=0, maximum=100)
        self.progress_bar.start()

        self.tone_mapping_thread = threading.Thread(target=self.run_tone_mapping, args=(event,))
        self.tone_mapping_thread.start()
        self.tone_mapping_thread.join()

        self.progress_bar.config(mode="determinate", value=0, maximum=100)
        self.progress_bar.stop()


    def run_tone_mapping(self, event=None):
        self.app.on_run_tone_mapping()
        self.download_button["state"] = tk.NORMAL



class ControlFrame(tk.Frame):
    width = 300
    height = 800

    preview_width = 260

    def __init__(self, parent, app):
        tk.Frame.__init__(self, parent)
        self.app = app

        self.main_frame = tk.Frame(
                            parent, width=self.width, height=self.height, 
                            padx=20, pady=20)
        self.main_frame.pack_propagate(0)
        self.main_frame.grid_propagate(0)

        self.parameter_frame = ParameterFrame(self.main_frame, app)
        self.parameter_frame.main_frame.pack(side=tk.TOP, fill="both", expand="True")
        self.parameter_frame.main_frame.grid_propagate(0)

        self.img_previewer = None
        if not self.app.filename:
            self.img_previewer = tk.Label(self.main_frame, text="", width=self.preview_width)
        else:
            self.imgtk = self.generate_preview_image('test_images/doll.hdr')
            self.img_previewer = tk.Label(self.main_frame, image=self.imgtk, width=self.preview_width)
            
        self.img_previewer.pack()


        action_buttons_frame = ActionButtonsFrame(self.main_frame, app)
        action_buttons_frame.main_frame.pack(side=tk.BOTTOM, fill="both")
        action_buttons_frame.main_frame.grid_propagate(0)


    def generate_preview_image(self, filename: str):
        img = General.hdr_read_for_thumbnail(filename)
        # img = General.bgr_to_rgb(img)
        
        scale = self.preview_width / img.shape[1]
        img = cv2.resize(img, (int(img.shape[1]*scale), int(img.shape[0]*scale)))
        
        im = Image.fromarray(img)
        return ImageTk.PhotoImage(image=im)


    def on_update_image_preview(self, filename: str):
        self.imgtk = self.generate_preview_image(filename)
        self.img_previewer.config(image=self.imgtk)

    
    def on_update_default_value(self):
        self.parameter_frame.on_update_default_value()



class ImageViewerFrame(tk.Frame):
    width = 800
    height = 800

    def __init__(self, parent, app):
        tk.Frame.__init__(self, parent)
        self.app = app

        self.main_frame = tk.Frame(parent, width=self.width, height=self.height, background="#000")

        self.img_viewer = tk.Label(self.main_frame, text=" ", width=self.width, background="#000")
        self.img_viewer.pack(fill='both', expand="True")
            


    def update_image_result(self, img: np.ndarray):
        orientation = "horizontal" if img.shape[0] < img.shape[1] else "vertical"
        scale = self.width / img.shape[1] if orientation == "horizontal" else self.height / img.shape[0]
        img = cv2.resize(img, (int(img.shape[1]*scale), int(img.shape[0]*scale)))
        img = General.bgr_to_rgb(img)
        im = Image.fromarray(img)
        self.imgtk = ImageTk.PhotoImage(image=im)
        self.img_viewer.config(image=self.imgtk)



class MyApp(tk.Tk):
    width = 1100
    height = 800

    method = Label.DURAND

    filename = None
    image = None
    result_8bit = None

    TONE_MAP = {
        Label.LOG: {
            "operator": log_tonemap,
            "L": None,
            "L_min": None,
            "L_max": None,
            "prev_alpha": None,
            "alpha": None,
            "t": None,
            "D": None,
            "output": None
        },
        Label.DURAND: {
            "operator": durand_tonemap,
            "L": None,
            "L_log_intensity": None,
            "prev_sigma_space": None,
            "prev_sigma_range": None,
            "prev_size": None,
            "sigma_space": None,
            "sigma_range": None,
            "size": None,
            "base_layer": None,
            "detail_layer": None,
            "prev_contrast": None,
            "contrast": None,
            "gamma": None,
            "D_prime": None,
            "D": None,
            "output": None
        }
    }

    def __init__(self, *args, **kwargs) -> None:
        tk.Tk.__init__(self, *args, **kwargs)

        main_frame = tk.Frame(self, width=self.width, height=self.height)
        main_frame.pack(fill="both", expand="True")

        self.control_frame = ControlFrame(main_frame, self)
        self.control_frame.main_frame.pack(side=tk.LEFT, fill="y")
        self.control_frame.main_frame.grid_propagate(0)
        self.image_viewer_frame = ImageViewerFrame(main_frame, self)
        self.image_viewer_frame.main_frame.pack(side=tk.RIGHT, fill="y")
        self.image_viewer_frame.main_frame.grid_propagate(0)


    def on_tonemap_attribute_change(self, method, attribute, value):
        self.TONE_MAP[method][attribute] = value


    def reset_tonemap_attributes(self):
        for method in self.TONE_MAP:
            for attribute in self.TONE_MAP[method]:
                if attribute != "operator":
                    self.TONE_MAP[method][attribute] = None


    def configure_default_value(self):
        self.TONE_MAP[Label.LOG]["alpha"] = General.LOG_ALPHA

        self.TONE_MAP[Label.DURAND]["contrast"] = General.DURAND_CONTRAST
        self.TONE_MAP[Label.DURAND]["sigma_space"] = General.DURAND_SIGMA_SPACE(self.image)
        self.TONE_MAP[Label.DURAND]["sigma_range"] = General.DURAND_SIGMA_RANGE
        self.TONE_MAP[Label.DURAND]["size"] = General.DURAND_SIZE(self.TONE_MAP[Label.DURAND]["sigma_space"])


    def on_file_upload(self, filename: str):
        self.filename = filename
        self.control_frame.on_update_image_preview(filename)
        self.image = General.hdr_read(self.filename)

        self.reset_tonemap_attributes()
        self.configure_default_value()
        self.control_frame.on_update_default_value()


    def on_run_tone_mapping(self):
        # result = self.TONE_MAP[self.method]["operator"](self.image)

        ## using customize function to reduce computation for unchanged parameters
        result = self.gui_durand_tonemap() if self.method == Label.DURAND else self.gui_log_tonemap()
        

        result = np.power(result, 1.0 / 2.2)
        # convert each channel to 8bit unsigned integer
        self.result_8bit = np.clip(result * 255, 0, 255).astype('uint8')
        self.image_viewer_frame.update_image_result(self.result_8bit)


    def on_download_result(self):
        import os
        from tkinter import messagebox

        # store the result
        target = "output/{filename}.{op}.png".format(filename=os.path.basename(self.filename), op=self.method.lower())
        msg_success = lambda: messagebox.showinfo(message="Converted '{filename}' to '{target}' with {op} operator.".format(
            filename=self.filename, target=target, op=self.method.lower()
        ))
        msg_fail = lambda: messagebox.showerror(message="Failed to write {0}".format(target))
        msg_success() if General.ldr_write(target, self.result_8bit) else msg_fail()


    def gui_durand_tonemap(self):
        durand = self.TONE_MAP[self.method]

        if not isinstance(durand["L_log_intensity"], np.ndarray):
            L = compute_luminance(self.image)
            L[L == 0] = np.finfo(np.float32).tiny
            L_log_intensity = np.log10(L)

            durand["L"] = L
            durand["L_log_intensity"] = L_log_intensity

        sigma_changed = False
        if not (durand["prev_sigma_space"] == durand["sigma_space"] and 
                durand["prev_sigma_range"] == durand["sigma_range"] and 
                durand["prev_size"] == durand["size"]):
            print("sigma_space, sigma_range, or size is tuned . . .")
            durand["base_layer"] = bilateral_filter(durand["L_log_intensity"], durand["size"], durand["sigma_space"], durand["sigma_range"])
            durand["detail_layer"] = durand["L_log_intensity"] - durand["base_layer"]

            sigma_changed = True

        if durand["contrast"] == durand["prev_contrast"] and not sigma_changed:
            print("no parameters were changed")
        else:
            print("recalculating all steps" if sigma_changed else "only contrast parameter is changed")
            gamma = np.log10(durand["contrast"]) / (np.max(durand["base_layer"]) - np.min(durand["base_layer"]))

            ## step 5
            D_prime = np.power(10, gamma * durand["base_layer"] + durand["detail_layer"])

            ## step 6
            D = D_prime / np.power(10, np.max(gamma * durand["base_layer"]))

            ## apply map luminanace
            durand["output"] = map_luminance(self.image, durand["L"], D)

            durand["prev_contrast"] = durand["contrast"]
            durand["prev_sigma_space"] = durand["sigma_space"]
            durand["prev_sigma_range"] = durand["sigma_range"]
            durand["prev_size"] = durand["size"]
            

        return durand["output"]


    def gui_log_tonemap(self):
        log_tonemap = self.TONE_MAP[self.method]

        if log_tonemap["alpha"] == log_tonemap["prev_alpha"]:
            print("no parameters were changed")            
        else:
            print("alpha parameter is changed")
            if not isinstance(log_tonemap["L"], np.ndarray):
                L = compute_luminance(self.image)
                L[L == 0] = np.finfo(np.float32).tiny 

                log_tonemap["L"] = L
                log_tonemap["L_min"] = np.min(L)
                log_tonemap["L_max"] = np.max(L)

            alpha = log_tonemap["alpha"]
            t = alpha * (log_tonemap["L_max"] - log_tonemap["L_min"])

            ## apply formula
            D = (np.log(log_tonemap["L"] + t) - np.log(log_tonemap["L_min"] + t)) / (np.log(log_tonemap["L_max"] + t) - np.log(log_tonemap["L_min"] + t))

            output = map_luminance(self.image, log_tonemap["L"], D)

            ## avoid power of base negative in testing cause of floating point error
            output = np.absolute(output)

            log_tonemap["output"] = output

            log_tonemap["prev_alpha"] = log_tonemap["alpha"]

        return log_tonemap["output"]
            


window_root = MyApp()
window_root.title("Tone Mapping - HDR Viewer")
window_root.geometry("{}x{}".format(window_root.width, window_root.height))
window_root.resizable(False, False)
# window_root.bind_all("<Button-1>", lambda event: event.widget.focus_set())

window_root.mainloop()