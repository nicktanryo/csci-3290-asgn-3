tone_mapping_extra.py consists the implementation of GUI application for tone mapping function.
This desktop app is build using Tkinter which can be run in windows, macos, and linux.]

this application dependencies will be:
    - tkinter (for GUI)
    - Pillow (for displaying image in tkinter)
    - opencv
    - given tonemap functions for tone_mapping.py (bilateral_filter, compute_luminance, log_tonemap, durand_tonemap, map_luminance)

It will support both log and durand methods of tone mapping with custamizable parameter, 
it also can preview the result of tonemap before user decide to download the image. 
custom tonemap functions are implemented to reduce some computation when tuning parameter (but the core logic remains the same)

The application usage can be in:
    0. Initially parameters will be None
    1. Upload image (there will be small preview and parameters will be loaded with recommended settings as given from specification)
    2. Run (should see result in right hand side)
    3. Tune parameters as needed or download result of tonemap

NOTE: - since I am implementing my own bilateral_filter for bonus point, 
      running durand method might be a little slower than using opencv built in API.
      (Progress bar using threading is provided to keep track of progress (not frozen))
      - Please reach out if the app cannot be run