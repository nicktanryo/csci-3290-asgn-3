#
# CSCI3290 Computational Imaging and Vision *
# --- Declaration --- *
# I declare that the assignment here submitted is original except for source
# material explicitly acknowledged. I also acknowledge that I am aware of
# University policy and regulations on honesty in academic work, and of the
# disciplinary guidelines and procedures applicable to breaches of such policy
# and regulations, as contained in the website
# http://www.cuhk.edu.hk/policy/academichonesty/ *
# Assignment 3
# Name : Nicholas Tanryo
# Student ID : 1155122022
# Email Addr : nicholas.tanryo@link.cuhk.edu.hk
#

from time import time
import cv2
import numpy as np
import os
import sys
import argparse


class ArgParser(argparse.ArgumentParser):
    """ ArgumentParser with better error message

    """

    def error(self, message):
        sys.stderr.write('error: %s\n' % message)
        self.print_help()
        sys.exit(2)


def hdr_read(filename: str) -> np.ndarray:
    """ Load a hdr image from a given path

    :param filename: path to hdr image
    :return: data: hdr image, ndarray type
    """
    data = cv2.imread(filename, cv2.IMREAD_ANYDEPTH)
    assert data is not None, "File {0} not exist".format(filename)
    assert len(data.shape) == 3 and data.shape[2] == 3, "Input should be a 3-channel color hdr image"
    return data


def ldr_write(filename: str, data: np.ndarray) -> None:
    """ Store a ldr image to the given path

    :param filename: target path
    :param data: ldr image, ndarray type
    :return: status: if True, success; else, fail
    """
    return cv2.imwrite(filename, data)


def compute_luminance(input: np.ndarray) -> np.ndarray:
    """ compute the luminance of a color image

    :param input: color image
    :return: luminance: luminance intensity
    """
    luminance = 0.2126 * input[:, :, 0] + 0.7152 * input[:, :, 1] + 0.0722 * input[:, :, 2]
    return luminance


def map_luminance(input: np.ndarray, luminance: np.ndarray, new_luminance: np.ndarray) -> np.ndarray:
    """ use contrast reduced luminace to recompose color image

    :param input: hdr image
    :param luminance: original luminance
    :param new_luminance: contrast reduced luminance
    :return: output: ldr image
    """
    # write you code here
    # to be completed
    
    ## apply formula for red, green, and blue seperately
    #   channel_output = input * (new_luminance=D / luminance=L)
    luminance_ratio = np.divide(new_luminance, luminance)
    channel_output = np.array([
        input[:,:, 0] * luminance_ratio,
        input[:,:, 1] * luminance_ratio,
        input[:,:, 2] * luminance_ratio
    ])
    channel_output = np.stack(channel_output, axis=2)

    output = channel_output

    # write you code here
    return output


def log_tonemap(input: np.ndarray) -> np.ndarray:
    """ global tone mapping with log operator

    :param input: hdr image
    :return: output: ldr image, value range [0, 1]
    """
    # write you code here
    # to be completed

    ## construct parameter
    L = compute_luminance(input)

    ## avoid having division by 0 in map_luminance
    L[L == 0] = np.finfo(np.float32).tiny 

    L_min = np.min(L)
    L_max = np.max(L)
    alpha = 0.05
    t = alpha * (L_max - L_min)

    ## apply formula
    D = (np.log(L + t) - np.log(L_min + t)) / (np.log(L_max + t) - np.log(L_min + t))

    output = map_luminance(input, L, D)

    ## avoid power of base negative in testing cause of floating point error
    output = np.absolute(output)

    # write you code here
    return output


def bilateral_filter(input: np.ndarray, size: int, sigma_space: float, sigma_range: float) -> np.ndarray:
    """ local tone mapping with durand's operator (bilateral filtering)

    :param input: input image/map
    :param size: windows size for spatial filtering
    :param sigma_space: filter sigma for spatial kernel
    :param sigma_range: filter sigma for range kernel
    :return: output: filtered output
    """
    # write you code here
    # to be completed

    start_time = time()

    ## using similar implementation with assignment 1
    def gaussian_kernel(size, sigma_space):
        kernel = np.zeros(shape=[size, size], dtype=float)

        denominator = 2 * np.pi * sigma_space**2
        power_denominator = 2 * sigma_space**2

        half_size = size // 2
        for i in range(size):
            for j in range(size):
                # reposition coordinate
                x, y = j - half_size, i - half_size
                kernel[i, j] = 1 / denominator * np.power(np.e, - (x**2 + y**2) / power_denominator)
        
        
        return kernel


    ## linear kernel for smoothing intensities
    def brightness_kernel(diff, sigma_range):
        return np.exp(-0.5 * np.power(diff, 2) / sigma_range**2) / (np.sqrt(2 * np.pi) * sigma_range)
        # return np.exp(np.e) / (np.sqrt(2 * np.pi) * sigma_range)


    output = np.zeros(input.shape)

    ## give padding for avoid size reduction for convolution
    padding_size = size // 2
    input = np.pad(input, ((padding_size, padding_size), (padding_size, padding_size)), 'reflect')


    ## get gaussian kernel
    gaussian_kernel_filter = gaussian_kernel(size, sigma_space)
    for i in range(output.shape[0]):
        for j in range(output.shape[1]):

            # start_y, end_y = 0, size
            # start_x, end_x = 0, size

            # if i < padding_size:
            #     start_y = padding_size - i
            # elif i >= output.shape[0] - padding_size - 1:
            #     end_y = padding_size + output.shape[0] - i - 1


            # if j < padding_size:
            #     start_x = padding_size - j
            # elif j >= output.shape[1] - padding_size - 1:
            #     end_x = padding_size + output.shape[1] - j - 1
            

            ## taking euclidiean distance for intensities matching
            diff = input[i:i+size, j:j+size] - input[i][j]
            brightness_kernel_filter = brightness_kernel(diff, sigma_range)


            ## multiply with original gaussian filter to get final kernel
            final_filter = gaussian_kernel_filter * brightness_kernel_filter
            # final_filter = final_filter[start_y:end_y, start_x:end_x]
            weight = final_filter / final_filter.sum()

            ## multiple and add corresponding weight to pixel value
            output[i][j] = (weight * input[i:i+size, j:j+size]).sum()
            # output[i][j] = (weight * input[i+start_y:i+end_y, j+start_x:j+end_x]).sum()


    print("############################ {} s ############################\n".format(time() - start_time))



    ## OpenCV API
    # output = cv2.bilateralFilter(input, size, sigma_range, sigma_space)

    # write you code here
    return output


def durand_tonemap(input: np.ndarray) -> np.ndarray:
    """ local tone mapping with durand's operator (bilateral filtering)

    :param input: hdr image
    :return: output: ldr image, value range [0, 1]
    """
    # write you code here
    # to be completed

    ## step 1
    L = compute_luminance(input)

    ## adjust luminance, avoid log10(0) error returns -np.inf
    L[L == 0] = np.finfo(np.float32).tiny

    L_log_intensity = np.log10(L)

    ## step 2
    sigma_space = 0.02 * min(input.shape[0], input.shape[1])
    sigma_range = 0.4
    size = int(2 * max(np.round(1.5 * sigma_space), 1) + 1)
    base_layer = bilateral_filter(L_log_intensity, size, sigma_space, sigma_range)

    ## step 3
    detail_layer = L_log_intensity - base_layer

    ## step 4
    contrast = 50
    gamma = np.log10(contrast) / (np.max(base_layer) - np.min(base_layer))

    ## step 5
    D_prime = np.power(10, gamma * base_layer + detail_layer)

    ## step 6
    D = D_prime / np.power(10, np.max(gamma * base_layer))

    ## apply map luminanace
    output = map_luminance(input, L, D)

    # write you code here
    return output


# operator dictionary
op_dict = {
    "durand": durand_tonemap,
    "log": log_tonemap
}

if __name__ == "__main__":
    # read arguments
    parser = ArgParser(description='Tone Mapping')
    parser.add_argument("filename", metavar="HDRImage", type=str, help="path to the hdr image")
    parser.add_argument("--op", type=str, default="all", choices=["durand", "log", "all"],
                        help="tone mapping operators")
    args = parser.parse_args()
    # print banner
    banner = "CSCI3290, Spring 2022, Assignment 3: tone mapping"
    bar = "=" * len(banner)
    print("\n".join([bar, banner, bar]))
    # read hdr image
    image = hdr_read(args.filename)


    # define the whole process for tone mapping
    def process(op: str) -> None:
        """ perform tone mapping with the given operator

        :param op: the name of specific operator
        :return: None
        """
        operator = op_dict[op]
        # tone mapping
        result = operator(image)
        # gamma correction
        result = np.power(result, 1.0 / 2.2)
        # convert each channel to 8bit unsigned integer
        result_8bit = np.clip(result * 255, 0, 255).astype('uint8')
        # store the result
        target = "output/{filename}.{op}.png".format(filename=os.path.basename(args.filename), op=op)
        msg_success = lambda: print("Converted '{filename}' to '{target}' with {op} operator.".format(
            filename=args.filename, target=target, op=op
        ))
        msg_fail = lambda: print("Failed to write {0}".format(target))
        msg_success() if ldr_write(target, result_8bit) else msg_fail()


    if args.op == "all":
        [process(op) for op in op_dict.keys()]
    else:
        process(args.op)
